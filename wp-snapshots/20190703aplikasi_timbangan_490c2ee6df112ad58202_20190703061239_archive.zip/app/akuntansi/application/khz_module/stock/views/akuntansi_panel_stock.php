<style>
.box-akuntansi{
  width: 100%; padding: 40px 0px; background: #fff; margin-bottom: 20px; border-bottom: 2px solid #42a5f5;
}
</style>

<div class="col-md-6 col-sm-6 col-xs-12">
    <div class="box-akuntansi" >
      <a href="<?php echo base_url('stock/laporanstock')?>">
        <div class="konten-akuntansi text-center">
          <i class="fa fa-file fa-3x"></i>
          <h3>Laporan Stock</h3>
        </div>
      </a>
    </div>
</div>

<div class="col-md-6 col-sm-6 col-xs-12">
    <div class="box-akuntansi" >
      <a href="<?php echo base_url('stock/masuk_stock')?>">
        <div class="konten-akuntansi text-center">
          <i class="fa fa-cube fa-3x"></i>
          <h3>Masuk Stock</h3>
        </div>
      </a>
    </div>
</div>

<div class="col-md-6 col-sm-6 col-xs-12">
    <div class="box-akuntansi" >
      <a href="<?php echo base_url('stock/stock_opname')?>">
        <div class="konten-akuntansi text-center">
          <i class="fa fa-tasks fa-3x"></i>
          <h3>Stock Opname</h3>
        </div>
      </a>
    </div>
</div>
