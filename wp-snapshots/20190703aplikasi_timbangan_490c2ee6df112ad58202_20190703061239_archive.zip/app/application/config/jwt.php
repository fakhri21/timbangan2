<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Author: takielias
 * Github Repo : https://github.com/takielias/codeigniter-websocket
 * Date: 04/05/2019
 * Time: 09:04 PM
 */
$config['jwt_key'] = '1Rdbv1ROUnC2sAoipLkj0mmm29a2OUTa';

/*Generated token will expire in 1 minute for sample code
* Increase this value as per requirement for production
*/
$config['token_timeout'] = 1;

/* End of file jwt.php */
/* Location: ./application/config/jwt.php */