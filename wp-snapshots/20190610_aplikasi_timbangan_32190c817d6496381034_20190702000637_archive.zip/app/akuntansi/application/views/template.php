<!DOCTYPE html>
<html lang="en">
<head>
  <title>Smart Parking</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php base_url();?>assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php base_url();?>assets/css/style.css">
  <script src="<?php base_url();?>assets/js/jquery.js"></script>
  <script src="<?php base_url();?>assets/js/bootstrap.min.js"></script>
</head>
<body style="background: url('<?php base_url();?>assets/image/bg.png');">

<!-- bagian container -->
<div class="container">
	<div class="wrapper">

		<?php echo $contents; ?>

		</div>	
<!-- footer-->
		<div class="footer">
		<center><small>Copyright © 2018 KHz TECHNOLOGY</small></center>
		</div>
	</div>
</div>

</body>
</html>